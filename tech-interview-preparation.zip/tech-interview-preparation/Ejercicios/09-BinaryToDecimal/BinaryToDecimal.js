function BinaryToDecimal(binary) {
  // Your code here:

}

module.exports = BinaryToDecimal;
