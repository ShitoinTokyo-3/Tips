function DecimalToBynary(num) {
  // Your code here:

}

module.exports = DecimalToBynary;
