class Node {
  // Your code here:

}

class MinStack {
  // Your code here:

}

module.exports = {
  Node,
  MinStack
}
