function HasBalancedBrackets(string) {
  // Your code here:

}

module.exports = HasBalancedBrackets;
