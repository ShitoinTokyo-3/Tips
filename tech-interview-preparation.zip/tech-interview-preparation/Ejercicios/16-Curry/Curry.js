function curry(fn) {
  // Your code here:

}

module.exports = curry;
