function FindNeedle (haystack, needle) {
  // Your code here:

}

module.exports = FindNeedle
