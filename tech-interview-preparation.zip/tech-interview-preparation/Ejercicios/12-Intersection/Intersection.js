function intersection(arr1, arr2) {
  // Your code here:

}

module.exports = intersection;
