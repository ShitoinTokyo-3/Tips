function spyOn(fn) {
  // Your code here:

}

module.exports = spyOn;
