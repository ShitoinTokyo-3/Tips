function mdArraySum(arr) {
  // Your code here:

}

module.exports = mdArraySum;
