function MaxValue (shares) {
  // Your code here:

}

module.exports = MaxValue
